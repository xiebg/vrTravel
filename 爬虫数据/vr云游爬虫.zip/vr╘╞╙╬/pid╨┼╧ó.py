import gzip
import bs4
import xlwt     # 进行Excel操作
import csv      # 进行csv操作
from bs4 import BeautifulSoup   # 网页解析
import requests
from pymysql import *

headers={
        # "authority": "rn01-sycdn.kuwo.cn",
        # "method": "GET",
        # "path": url,
        "scheme": "https",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        # "accept-encoding": "gzip, deflate, br",   # 可能会出现乱码
        "accept-encoding": "gzip",
        "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
        "cache-control": "no-cache",
        # "cookie": "_ga=GA1.2.340260792.1623853001; _gid=GA1.2.1623149410.1623853001; Hm_lvt_cdb524f42f0ce19b169a8071123a4797=1623853001,1623931172; Hm_lpvt_cdb524f42f0ce19b169a8071123a4797=1623931172",
        "pragma": "no-cache",
        "sec-ch-ua": "\" Not;A Brand\";v=\"99\", \"Microsoft Edge\";v=\"91\", \"Chromium\";v=\"91\"",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36 Edg/91.0.864.48"
}

# get数据请求
def getUrl(url):
    try:
        resp = requests.get(url, headers=headers, timeout = 30)
        resp.raise_for_status()
        resp.encoding = "utf-8"  #根据网页编码解析解码
        return resp
    except:
        return None

# post数据请求
def postUrl(url,data):
    try:
        resp = requests.post(url, data=data, headers=headers, timeout = 30)
        resp.raise_for_status()
        resp.encoding = resp.apparent_encoding
        return resp
    except:
        return None

def saveCsv(dictData,name,Tag = False):
    """
    保存的csv文件先用记事本打开，
    然后另存为ANSI编码的文件，
    最后用excel打开即可！！！
    :param dictData: 字典类型数据[{}.{},..]
    :param name: 保存的文件名
    :return: null
    """
    print("爬取的数据将保存在csv文件中..")
    with open(f'{name}.csv', 'a', encoding='utf-8',newline='') as csvfile:
        fp = csv.DictWriter(csvfile,fieldnames=dictData.keys())
        if Tag:
            fp.writeheader()
        try:
            fp.writerows(dictData)
        except Exception as e:
            print(e)

def search_jingdian(pn = 0,geo = 254,b = "(11401960.27,3855236.8729910725;11845119.518660713,4313127.177008928)"):
    # 创建Connection连接
    conn = connect(host='localhost', port=3306, database='login', user='root', password='123456', charset='utf8')
    # 获得Cursor对象
    cursor = conn.cursor()
    name = "内景uid"
    wd = "景点"
    c = geo
    nn = (pn-1)*10
    auth = "uxLHRERHBNxtDBKKYKKQHWyKxACV=z8yvkGcuVtvvhguVtvyheuVtvCMGuVtvCQMuETt1P7kDFCw8wkv7uvZgMuVtv@vcuVtvc3CuVtvcPPuVtveGvuzLEtzhl4yYxvhgMuzVVtvrMhuxLztexZFTHrwz6v5gOpPkhjaKck@9Syncpj@b4tfsqk90c03M8VdSdVP8hJGccZcuxtf0wd0vyMISFSICM7"
    seckey = "4OXBVWLngyqYEF/6QtS7KsONeEHIxsTP6+5dF/H3eWM=,fFXgk5uWoY_OLaYEBfVVWooLkzdoct4ot2HHss74JkNex1SWFrXZPQjVhWk643j9fzSCXK9NapeXhanN0rncHYnX1C-AA5FVnQ37zzLj0mSavWPh5DBfScxSbMJV8-Bc-E8H5mxq8OMNsB3RqiLpqQZa4ShgY5n3eUocsxYtO3ImG-oTJDGxdhJeLUD1kpoT"
    url = f"https://map.baidu.com/?newmap=1&reqflag=pcmap&biz=1&from=webmap&da_par=direct&pcevaname=pc4.1&qt=con&from=webmap&c={c}&wd={wd}&wd2=&pn={pn}&nn={nn}&db=0&sug=0&addr=0&pl_data_type=scope&pl_sub_type=&pl_price_section=0%2C%2B&pl_sort_type=&pl_sort_rule=0&pl_discount2_section=0%2C%2B&pl_groupon_section=0%2C%2B&pl_cater_book_pc_section=0%2C%2B&pl_hotel_book_pc_section=0%2C%2B&pl_ticket_book_flag_section=0%2C%2B&pl_movie_book_section=0%2C%2B&pl_business_type=scope&pl_business_id=&da_src=pcmappg.poi.page&on_gel=1&src=7&gr=3&l=10&auth={auth}&seckey={seckey}&device_ratio=2&tn=B_NORMAL_MAP&u_loc=11724830,4110132&ie=utf-8&b={b}&t=1658377404161&newfrom=zhuzhan_webmap"
    resp = getUrl(url).json()
    # print(resp)
    addrdata = {}
    for i in range(len(resp["content"])-1):
        addrdata["name"] = resp["content"][i]["name"]
        addrdata["addr"] = resp["content"][i]["addr"]
        addrdata["x"] = resp["content"][i]["x"]
        addrdata["y"] = resp["content"][i]["y"]
        addrdata["uid"] = resp["content"][i]["uid"]
        # addrdata["navi_x"]  = resp["content"][i]["navi_x"]
        # addrdata["navi_y"] = resp["content"][i]["navi_y"]
        print(addrdata)
        # if pn == 1:
        #     saveCsv(addrdata,name, True)
        # else:
        #     saveCsv(addrdata, name, False)
        # try:
        sql = "insert into pano_table (pano_name, pano_addr, pano_x, pano_y, pano_uid) VALUE(" + "\'" + addrdata[
            "name"] + "\'" + "," + "\'" + addrdata["addr"] + "\'" + "," + "\'" + str(addrdata["x"]) + "\'" + "," + "\'" + str(addrdata["y"]) + "\'"+ "," + "\'" + addrdata["uid"] + "\'" + ");"
        # print(sql)
        count = cursor.execute(sql)
        conn.commit()
        # print(count.fetchone())
        # except Exception as e:
        #     print(e)



# for i in range(1,30):
#     # 天水 196 (11401960.27,3855236.8729910725;11845119.518660713,4313127.177008928)
#     # 三明 254 (13092566.59,3007469.65;13100246.59,3019405.65)
#     # 北京 131 (12943878.56,4801475.47;12974598.56,4849219.47）
#     # 上海 289 (13507905.31,3617242.64;13538625.31,3664986.64)
#     # 厦门 194 (13125528.15,2770978.59;13167512.15,2818722.59)
#     search_jingdian(i,194,"(13125528.15,2770978.59;13167512.15,2818722.59)")