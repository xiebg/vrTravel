import csv      # 进行csv操作
import requests
from pymysql import *


headers={
        # "authority": "rn01-sycdn.kuwo.cn",
        # "method": "GET",
        # "path": url,
        "scheme": "https",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        # "accept-encoding": "gzip, deflate, br",   # 可能会出现乱码
        "accept-encoding": "gzip",
        "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
        "cache-control": "no-cache",
        # "cookie": "_ga=GA1.2.340260792.1623853001; _gid=GA1.2.1623149410.1623853001; Hm_lvt_cdb524f42f0ce19b169a8071123a4797=1623853001,1623931172; Hm_lpvt_cdb524f42f0ce19b169a8071123a4797=1623931172",
        "pragma": "no-cache",
        "sec-ch-ua": "\" Not;A Brand\";v=\"99\", \"Microsoft Edge\";v=\"91\", \"Chromium\";v=\"91\"",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36 Edg/91.0.864.48"
}
# get数据请求
def getUrl(url):
    try:
        resp = requests.get(url, headers=headers, timeout = 30)
        resp.raise_for_status()
        resp.encoding = "utf-8"  #根据网页编码解析解码
        return resp
    except:
        return None

# post数据请求
def postUrl(url,data):
    try:
        resp = requests.post(url, data=data, headers=headers, timeout = 30)
        resp.raise_for_status()
        resp.encoding = resp.apparent_encoding
        return resp
    except:
        return None

def saveCsv(dictData,name,Tag = False):
    """
    保存的csv文件先用记事本打开，
    然后另存为ANSI编码的文件，
    最后用excel打开即可！！！
    :param dictData: 字典类型数据[{}.{},..]
    :param name: 保存的文件名
    :return: null
    """
    print("爬取的数据将保存在csv文件中..")
    with open(f'{name}.csv', 'a', encoding='utf-8',newline='') as csvfile:
        fp = csv.DictWriter(csvfile,fieldnames=dictData[0].keys())
        if Tag:
            fp.writeheader()
        try:
            fp.writerows(dictData)
        except Exception as e:
            print(e)

# https://lbsyun.baidu.com/index.php?title=webapi/weather
# lb24UtgyfPZwv3OoDOcaA7gBoPIFcBmD
# https://api.map.baidu.com/place/v2/search?query=ATM机&tag=银行&region=北京&output=json&ak=您的ak //GET请求
url = "https://api.map.baidu.com/place/v2/search?query=内景&tag=全景&region=北京&output=json&ak=lb24UtgyfPZwv3OoDOcaA7gBoPIFcBmD&page_size=20"

resp = getUrl(url).json()
print(resp)
