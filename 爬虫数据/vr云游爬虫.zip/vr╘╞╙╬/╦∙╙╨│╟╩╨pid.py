import csv      # 进行csv操作
import requests

import pid信息 as pid
from pymysql import *
headers={
        # "authority": "rn01-sycdn.kuwo.cn",
        # "method": "GET",
        # "path": url,
        "scheme": "https",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        # "accept-encoding": "gzip, deflate, br",   # 可能会出现乱码
        "accept-encoding": "gzip",
        "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
        "cache-control": "no-cache",
        # "cookie": "_ga=GA1.2.340260792.1623853001; _gid=GA1.2.1623149410.1623853001; Hm_lvt_cdb524f42f0ce19b169a8071123a4797=1623853001,1623931172; Hm_lpvt_cdb524f42f0ce19b169a8071123a4797=1623931172",
        "pragma": "no-cache",
        "sec-ch-ua": "\" Not;A Brand\";v=\"99\", \"Microsoft Edge\";v=\"91\", \"Chromium\";v=\"91\"",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36 Edg/91.0.864.48"
}
# get数据请求
def getUrl(url):
    try:
        resp = requests.get(url, headers=headers, timeout = 30)
        resp.raise_for_status()
        resp.encoding = "utf-8"  #根据网页编码解析解码
        return resp
    except:
        return None

# post数据请求
def postUrl(url,data):
    try:
        resp = requests.post(url, data=data, headers=headers, timeout = 30)
        resp.raise_for_status()
        resp.encoding = resp.apparent_encoding
        return resp
    except:
        return None
def saveCsv(dictData,name,Tag = False):
    """
    保存的csv文件先用记事本打开，
    然后另存为ANSI编码的文件，
    最后用excel打开即可！！！
    :param dictData: 字典类型数据[{}.{},..]
    :param name: 保存的文件名
    :return: null
    """
    print("爬取的数据将保存在csv文件中..")
    with open(f'{name}.csv', 'a', encoding='utf-8',newline='') as csvfile:
        fp = csv.DictWriter(csvfile,fieldnames=dictData[0].keys())
        if Tag:
            fp.writeheader()
        try:
            fp.writerows(dictData)
        except Exception as e:
            print(e)

def get_city():
    url = "https://map.baidu.com/?newmap=1&reqflag=pcmap&biz=1&from=webmap&da_par=direct&pcevaname=pc4.1&qt=s&da_src=searchBox.button&wd=%E6%97%85%E6%B8%B8&c=1&src=0&wd2=&pn=0&sug=0&l=5&b=(8976723.22,1613659.88;14235987.22,7724891.88)&from=webmap&biz_forward={%22scaler%22:2,%22styles%22:%22pl%22}&sug_forward=&auth=ES117dBfIzyKxRPJDWxB543X4GdbzTLJuxLHRERzRBVtAyII7IIOFUvCuyAT9xXwvkGcuVtvvhguVtcvY1SGpuHtADmiz8yvCMGuVtvCQMuETt1P7kDFCw8wkv7uvZgMuVtv%40vcuVtvc3CuVtvcPPuVtveGvuzVLtBjnOADzwi04vA77uvrMhuxEVtGccZcuxtf0wd0vyMISFSASAU&seckey=4OXBVWLngyqYEF%2F6QtS7KsONeEHIxsTP6%2B5dF%2FH3eWM%3D%2CfFXgk5uWoY_OLaYEBfVVWooLkzdoct4ot2HHss74JkNex1SWFrXZPQjVhWk643j9fzSCXK9NapeXhanN0rncHYnX1C-AA5FVnQ37zzLj0mSavWPh5DBfScxSbMJV8-Bc-E8H5mxq8OMNsB3RqiLpqQZa4ShgY5n3eUocsxYtO3ImG-oTJDGxdhJeLUD1kpoT&device_ratio=2&tn=B_NORMAL_MAP&nn=0&u_loc=11731983,4115085&ie=utf-8&t=1658482841262&newfrom=zhuzhan_webmap"
    resp = getUrl(url).json()
    citys = []
    for i in range(29):
        c = resp['more_city'][i]['city']
        for j in range(len(c)):
            city = {}
            city['name'] = c[j]['name']
            city['code'] = c[j]['code']
            city['geo'] = c[j]['geo'].split("|")[1]
            # print(city)
            citys.append(city)
    return citys


# saveCsv(citys,"百度地图所有城市代码",Tag = True)

# print(resp)
# for ct in citys:
#     for i in range(3,30):
#         print(ct)
#         try:
#             print(str(ct["code"])+f"({ct['geo']})")
#             pid.search_jingdian(i, ct["code"], f"({ct['geo']})")
#
#         except Exception as e:
#             print("已爬完"+e)


def get_data(add):
    url = f"https://api.map.baidu.com/place/v2/search?query=旅游&tag=全景&region={add}&output=json&ak=lb24UtgyfPZwv3OoDOcaA7gBoPIFcBmD&page_size=20"
    # 创建Connection连接
    conn = connect(host='localhost', port=3306, database='login', user='root', password='123456', charset='utf8')
    # 获得Cursor对象
    cursor = conn.cursor()
    resp = getUrl(url).json()
    print(len(resp['results']))
    addrdata = {}
    for i in range(20):
        addrdata["name"] = resp["results"][i]["name"]
        addrdata["addr"] = resp["results"][i]["address"]
        addrdata["x"] = resp["results"][i]['location']["lat"]
        addrdata["y"] = resp["results"][i]['location']["lng"]
        addrdata["uid"] = resp["results"][i]["uid"]
        print(addrdata)
        sql = "insert into pano_table (pano_name, pano_addr, pano_x, pano_y, pano_uid) VALUE(" + "\'" + addrdata[
            "name"] + "\'" + "," + "\'" + addrdata["addr"] + "\'" + "," + "\'" + str(
            addrdata["x"]) + "\'" + "," + "\'" + str(addrdata["y"]) + "\'" + "," + "\'" + addrdata["uid"] + "\'" + ");"
        # print(sql)
        count = cursor.execute(sql)
        conn.commit()

adds = get_city()
for add in adds:
    try:
        get_data(add['name'])
    except Exception:
        print("====")