package com.alibaba.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import javax.annotation.PostConstruct;
import java.sql.*;


/**
 * @author:颉海鹏
 * @create:2022-06-23:01
 **/
@Component
public class TableConfig{

    @Value("${spring.datasource.driver-class-name}")
    private String driver;

    @Value(value = "${spring.datasource.url}")
    private String url;

    @Value(value = "${spring.datasource.username}")
    private String userName;

    @Value(value = "${spring.datasource.password}")
    private String password;


    @PostConstruct
    public void init() throws SQLException, ClassNotFoundException{

        System.out.println(driver);
        System.out.println(url);
        System.out.println(userName);
        System.out.println(password);

        driver = "com.mysql.jdbc.Driver";
        url = "jdbc:mysql://localhost:3306/login?serverTimezone=UTC&characterEncoding=utf-8&useSSL=false&useUnicode=true";
        userName = "root";
        password = "123456";

        //连接数据库
        Class.forName(driver);
        //测试url中是否包含useSSL字段，没有则添加设该字段且禁用
        if( url.indexOf("?") == -1 ){
            url = url + "?useSSL=false" ;
        }
        else if( url.indexOf("useSSL=false") == -1 || url.indexOf("useSSL=true") == -1 )
        {
            url = url + "&useSSL=false";
        }
        Connection conn = DriverManager.getConnection(url, userName, password);
        Statement stat = conn.createStatement();
        //获取数据库表名
        ResultSet rs = conn.getMetaData().getTables(null, null, "user", null);

        // 判断表是否存在，如果存在则什么都不做，否则创建表
        if( rs.next() ){
            return;
        }
        else{
            // 先判断是否纯在表名，有则先删除表在创建表
//            stat.executeUpdate("DROP TABLE IF EXISTS user;");
            //创建行政区划表
            stat.executeUpdate("CREATE TABLE " + "user" + " (" +
                    "  `id` bigint(20) NOT NULL AUTO_INCREMENT," +
                    "  `username` varchar(30) NOT NULL," +
                    "  `password` varchar(30) NOT NULL," +
                    "  PRIMARY KEY (`id`) USING BTREE" +
                    ");"
            );
        }
        // 释放资源
        stat.close();
        conn.close();
    }
}
