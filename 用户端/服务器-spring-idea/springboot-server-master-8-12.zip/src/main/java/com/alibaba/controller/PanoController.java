package com.alibaba.controller;

import com.alibaba.bean.News;
import com.alibaba.bean.Pano;
import com.alibaba.service.NewsService;
import com.alibaba.service.PanoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-07-15:53
 **/

@RestController
@RequestMapping("/pano")
public class PanoController {
    @Autowired
    private PanoService panoService;


    @GetMapping(value = "/1")
    public Pano findPano(Long uid){
        Pano pano = panoService.findPanoById(uid);
        System.out.println(pano.getUid());
        return pano;
    }

    @GetMapping(value = "/all")
    public List<Pano> findPanoAll(){
        List<Pano> panos = panoService.findPanoAllList();
//        System.out.println(news.getUid());
        return panos;
    }

    @GetMapping(value = "/panoname")
    public List<Pano> findPano(String name){
        List<Pano> panos = panoService.findPanoByName(name);
//        System.out.println(panos.getUid());
        return panos;
    }

}
