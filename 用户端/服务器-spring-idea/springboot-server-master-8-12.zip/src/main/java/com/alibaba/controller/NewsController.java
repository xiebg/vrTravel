package com.alibaba.controller;


import com.alibaba.bean.News;
import com.alibaba.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-06-22:48
 **/
@RestController
@RequestMapping("/news")
public class NewsController {

    @Autowired
    private NewsService newsService;


    @GetMapping(value = "/1")
    public News findNews(Long uid){
        News news = newsService.findNewsById(uid);
        System.out.println(news.getUid());
        return news;
    }

    @GetMapping(value = "/all")
    public List<News> findNews(){
        List<News> newss = newsService.findNewsAllList();
//        System.out.println(news.getUid());
        return newss;
    }

    @GetMapping(value = "/newstitle")
    public List<News> findNewsByTitle(String title){
        List<News> newss = newsService.findNewsByTitle(title);
//        System.out.println(news.getUid());
        return newss;
    }

}
