package com.alibaba.mapper;

import com.alibaba.bean.IndoorPano;
import com.alibaba.bean.News;
import com.alibaba.bean.Pano;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-07-12:47
 **/

@Mapper
@Repository
public interface IndoorMapper {
    @Insert(value = "insert into indoorpano_table(addrname, pid) value (#{addrname},#{pid})")
    void insertAIndoor(String addrname, String pid);

    @Select(value = "select * from indoorpano_table where id = #{id}")
    IndoorPano findIndoornoById(Long id);


    @Select(value = "select * from indoorpano_table")
    List<IndoorPano> findIndoorPanosAll();

    @Select(value = "select * from indoorpano_table where indoorpano_table.addrname like concat('%',#{name},'%')")
    List<IndoorPano> findIndoorPanoByName(String name);

    @Select(value = "select * from hotelpano_table")
    List<IndoorPano> findHotelPanosAll();

    @Select(value = "select * from hotelpano_table where hotelpano_table.addrname like concat('%',#{name},'%')")
    List<IndoorPano> findHotelPanoByName(String name);

}
