package com.alibaba.service;
import com.alibaba.bean.News;
import com.alibaba.mapper.NewsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-06-22:49
 **/
@Service
@Transactional(rollbackFor = RuntimeException.class)
public class NewsService {

    @Autowired
    private NewsMapper newsMapper;

    public News findNewsById(Long id){
        News news = newsMapper.findNewsById(id);
        return news;
    }

    public List<News> findNewsAllList(){
        List<News> newses = newsMapper.findNewsAll();
        return newses;
    }

    public List<News> findNewsByTitle(String title){
        List<News> newses = newsMapper.findNewsByTitle(title);
        return newses;
    }

}
