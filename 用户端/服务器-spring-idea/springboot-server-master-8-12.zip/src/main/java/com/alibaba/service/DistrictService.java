package com.alibaba.service;


import com.alibaba.bean.IndoorPano;
import com.alibaba.mapper.DistrictMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-08-23:16
 **/
@Service
@Transactional(rollbackFor = RuntimeException.class)
public class DistrictService {
    @Autowired
    private DistrictMapper districtMapper;


    public String findDistrictByCity(String city){
        String districtByCity = districtMapper.findDistrictByCity(city);
        return districtByCity;
    }
}
