package com.alibaba.service;

import com.alibaba.bean.IndoorPano;
import com.alibaba.bean.News;
import com.alibaba.bean.Pano;
import com.alibaba.mapper.IndoorMapper;
import com.alibaba.mapper.NewsMapper;
import com.alibaba.mapper.PanoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-07-12:59
 **/
@Service
@Transactional(rollbackFor = RuntimeException.class)
public class IndoorService {

    @Autowired
    private IndoorMapper indoorMapper;

    public void addAIndoor(String addrname,String pid){
        indoorMapper.insertAIndoor(addrname,pid);
    }

    public IndoorPano findIndoornoById(Long id){
        IndoorPano indoorPano = indoorMapper.findIndoornoById(id);
        return indoorPano;
    }

    public List<IndoorPano> findIndoorPanosAll(){
        List<IndoorPano> indoorPanos =  indoorMapper.findIndoorPanosAll();
        return indoorPanos;
    }

    public List<IndoorPano> findIndoorPanoByName(String name){
        List<IndoorPano> indoorPanos =  indoorMapper.findIndoorPanoByName(name);
        return indoorPanos;
    }

    public List<IndoorPano> findHotelPanosAll(){
        List<IndoorPano> indoorPanos =  indoorMapper.findHotelPanosAll();
        return indoorPanos;
    }

    public List<IndoorPano> findHotelPanoByName(String name){
        List<IndoorPano> indoorPanos =  indoorMapper.findHotelPanoByName(name);
        return indoorPanos;
    }

}
