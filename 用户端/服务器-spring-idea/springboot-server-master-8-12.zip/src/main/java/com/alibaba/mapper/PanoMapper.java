package com.alibaba.mapper;

import com.alibaba.bean.News;
import com.alibaba.bean.Pano;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-06-22:30
 **/
@Mapper
@Repository

public interface PanoMapper {

    @Select(value = "select * from pano_table where uid = #{uid}")
    @Results
            ({      @Result(property = "uid",column = "uid"),
                    @Result(property = "panoName",column = "pano_name"),
                    @Result(property = "panoAddr",column = "pano_addr"),
                    @Result(property = "panoX",column = "pano_x"),
                    @Result(property = "panoY",column = "pano_y"),
                    @Result(property = "panoUid",column = "pano_uid"),
                    @Result(property = "createTime",column = "create_time"),
                    @Result(property = "newsDel",column = "news_del"),
            })
    Pano findPanoById(Long uid);


    @Select(value = "select * from pano_table")
    @Results
            ({      @Result(property = "uid",column = "uid"),
                    @Result(property = "panoName",column = "pano_name"),
                    @Result(property = "panoAddr",column = "pano_addr"),
                    @Result(property = "panoX",column = "pano_x"),
                    @Result(property = "panoY",column = "pano_y"),
                    @Result(property = "panoUid",column = "pano_uid"),
                    @Result(property = "createTime",column = "create_time"),
                    @Result(property = "newsDel",column = "news_del"),
            })
    List<Pano> findPanosAll();

    @Select(value = "select * from pano_table where pano_addr like concat('%',#{name},'%')")
    @Results
            ({      @Result(property = "uid",column = "uid"),
                    @Result(property = "panoName",column = "pano_name"),
                    @Result(property = "panoAddr",column = "pano_addr"),
                    @Result(property = "panoX",column = "pano_x"),
                    @Result(property = "panoY",column = "pano_y"),
                    @Result(property = "panoUid",column = "pano_uid"),
                    @Result(property = "createTime",column = "create_time"),
                    @Result(property = "newsDel",column = "news_del"),
            })
    List<Pano> findPanoByName(String name);



}
