package com.alibaba.service;
import com.alibaba.bean.Pano;
import com.alibaba.mapper.PanoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-06-22:49
 **/
@Service
@Transactional(rollbackFor = RuntimeException.class)
public class PanoService {

    @Autowired
    private com.alibaba.mapper.PanoMapper PanoMapper;

    public Pano findPanoById(Long id){
        Pano pano = PanoMapper.findPanoById(id);
        return pano;
    }

    public List<Pano> findPanoAllList(){
        List<Pano> panos =  PanoMapper.findPanosAll();
        return panos;
    }

    public List<Pano> findPanoByName(String name){
        List<Pano> panos =  PanoMapper.findPanoByName(name);
        return panos;
    }

}
