package com.alibaba.mapper;

import com.alibaba.bean.News;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-06-22:30
 **/
@Mapper
@Repository

public interface NewsMapper {

    @Select(value = "select * from news_table where uid = #{uid}")
    @Results
            ({      @Result(property = "uid",column = "uid"),
                    @Result(property = "newsTitle",column = "news_title"),
                    @Result(property = "newsContent",column = "news_content"),
                    @Result(property = "newsSource",column = "news_source"),
                    @Result(property = "createTime",column = "create_time"),
                    @Result(property = "newsDel",column = "news_del"),
            })
    News findNewsById(Long uid);


    @Select(value = "select * from news_table")
    @Results
            ({      @Result(property = "uid",column = "uid"),
                    @Result(property = "newsTitle",column = "news_title"),
                    @Result(property = "newsContent",column = "news_content"),
                    @Result(property = "newsSource",column = "news_source"),
                    @Result(property = "createTime",column = "create_time"),
                    @Result(property = "newsDel",column = "news_del"),
            })
    List<News> findNewsAll();

    @Select(value = "select * from news_table where news_title like concat('%',#{title},'%')")
    @Results
            ({      @Result(property = "uid",column = "uid"),
                    @Result(property = "newsTitle",column = "news_title"),
                    @Result(property = "newsContent",column = "news_content"),
                    @Result(property = "newsSource",column = "news_source"),
                    @Result(property = "createTime",column = "create_time"),
                    @Result(property = "newsDel",column = "news_del"),
            })
    List<News> findNewsByTitle(String title);
}
