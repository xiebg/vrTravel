package com.alibaba.controller;

import com.alibaba.bean.IndoorPano;
import com.alibaba.service.DistrictService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-08-23:20
 **/
@RestController
@RequestMapping("/district")
public class DistrictController {
    @Autowired
    private DistrictService districtService;

    @GetMapping(value = "/findid")
    public String findPano(String city){
        String districtByCity = districtService.findDistrictByCity(city);
        return districtByCity;
    }

}
