package com.alibaba.controller;

import com.alibaba.bean.IndoorPano;
import com.alibaba.bean.News;
import com.alibaba.bean.Pano;
import com.alibaba.service.IndoorService;
import com.alibaba.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-07-13:07
 **/
@RestController
@RequestMapping("/indoor")
public class IndoorController {
    @Autowired
    private IndoorService indoorService;

    @GetMapping(value = "/add")
    public String addAIndoor(String addrname,String pid){
        indoorService.addAIndoor(addrname,pid);
        return "成功!";
    }

    @GetMapping(value = "/findid")
    public IndoorPano findIndoornoById(Long id){
        IndoorPano indoorPano = indoorService.findIndoornoById(id);
        System.out.println(indoorPano.getId());
        return indoorPano;
    }

    @GetMapping(value = "/findall")
    public List<IndoorPano> findIndoorPanosAll(){
        List<IndoorPano> indoorPanos = indoorService.findIndoorPanosAll();
        return indoorPanos;
    }

    @GetMapping(value = "/findname")
    public List<IndoorPano> findIndoorPanosByName(String name){
        List<IndoorPano> IndoorPanos = indoorService.findIndoorPanoByName(name);
        System.out.print(IndoorPanos);
        return IndoorPanos;
    }

    @GetMapping(value = "/findhotelall")
    public List<IndoorPano> findHotelPanosAll(){
        List<IndoorPano> indoorPanos = indoorService.findHotelPanosAll();
        return indoorPanos;
    }

    @GetMapping(value = "/findhotelname")
    public List<IndoorPano> findHotelPanosByName(String name){
        List<IndoorPano> IndoorPanos = indoorService.findHotelPanoByName(name);
        System.out.print(IndoorPanos);
        return IndoorPanos;
    }
}
