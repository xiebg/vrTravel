package com.alibaba.mapper;

import com.alibaba.bean.IndoorPano;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author:颉海鹏
 * @create:2022-08-23:08
 **/
@Mapper
@Repository
public interface DistrictMapper {
    @Select(value = "select city_geocode from weather_district_id where district = #{city}")
    String findDistrictByCity(String city);
}
